﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Dialogue: ScriptableObject
{

    public List<DialogueElement> DialogItems;

}
