﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BurgerComponentInstantiator : MonoBehaviour {

    public bool isTutorial = false;
    public bool broken = false;
    
    //necessary scripts + gameobjects
    public PlayerHealth ph;
    public GameObject player;
    public EnemyBehavior eb;
    public TutorialEnemy te;
    public GameObject enemy;
    public GameObject MainCamera;
    public GameObject CombatUI;

    public float originalBurgerPosition;
    public float burgerPosition; //add 0.2 per pixel of the object
    float formerBurgerPosition; //burger position before prefab was instantiated
    public float sinkBP; //reduces burgerposition by amount

    public bool canSpawn; //called by animations when they go static
    //bool bottomPlaced; //set when bottom bun is placed - defunct
    bool topPlaced; //set when top bun is placed
    public bool spawnReset; //checked by individual component to despawn
    public int componentNumber; //number of components 
    public int bounceTrigger; //used to determine bouncing
    public int componentCap; //caps components to this int
    public int turns; //tracks how many turns have passed
    public int critRoll; //variable for tracking crit

    public Image bottomBun; //all prefabs that are instantiated
    public Image tomato;
    public Image lettuce;
    public Image onion;
    public Image bacon;
    public Image sauce;
    public Image pickles;
    public Image ketchup;
    public Image mustard;
    public Image cheese;
    public Image patty;
    public Image topBun;
    public int[] componentCount = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };

    public int[] finalCombo; //array checked against combos when topbun comes down
    public int fcArray; //array location set by components
    public Text comboText; // text that displays combo name
    bool noCombo; //true when no combo matches final array;

    public Text[] infoText; //gives info about ingredients
    public Animator[] iconAnim; //icons flash when buttons are pressed
    public Text[] iconText; //text giving information about ingredients

    //combo strings. identity: 0 = blank, 1 = tomato, 2 = lettuce, 3 = onion, 4 = bacon, 5 = sauce, 6 = pickles, 7 = ketchup, 8 = mustard, 9 = cheese, 10 = patty
    public int[] classicCombo3 = { 7, 8, 6, 10, 9, 1, 2, 3, 5, 0 };
    public int[] baconCombo = { 9, 10, 9, 4, 10, 9, 4, 7, 5, 0 };
    public int[] simpleCombo = { 10, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
    public int[] classicCombo = { 10, 1, 2, 3, 0, 0, 0, 0, 0, 0 };
    public int[] veggieCombo = { 2, 10, 2, 0, 0, 0, 0, 0, 0, 0 };
    public int[] weepCombo = { 3, 10, 3, 2, 1, 0, 0, 0, 0, 0 };
    public int[] doubleCombo = { 10, 1, 2, 3, 10, 0, 0, 0, 0, 0 };
    public int[] doubleCombo3 = { 10, 1, 2, 3, 10, 0, 0, 0, 0, 0 };
    public int[] TripleMeatCombo = { 10, 1, 2, 10, 9, 10, 9, 10, 0, 0 };

    //subcombo strings, same as above but you can have multiple and some are bad
    public int[] twoPatt = { 10, 10 };
    public int[] burgCheese = { 10, 9 };

    //final attack stats - ingredient modified
    public float dropMult; //multiplies loot recieved when fight is over
    public float heal; //amount healed
    public int crying; //adds to enemy miss chance - stacked with diminishing returns
    public float damageMult; //multiplies damage
    public float critChance; //adds flat amount to percentage crit chance
    public float armorPen = 0; //penetrates enemy armor by flat amount
    public bool ketchupDamage; // if active, deals ketchup damage
    public bool mustardDamage; // if active, deals mustard damage
    public int slow; //slows enemy by percentage amount - stacked with diminishing returns
    public float damage; //raw damage number
    public float finalDamage; //final damage number after multipliers and resistances are taken into account

    public bool pattyDropped; // active when a patty is dropped
    public bool playerDead; // true when dead

    // player variables INV = inventory
    public int[] ingredientINV = new int[10];

    // text displaying stats
    public Text dropText;
    public Text healText;
    public Text cryingText;
    public Text critChanceText;
    public Text armorPenText;
    public Text damageTypeText;
    public Text slowText;
    public Text damageText;

    //beginning and ending UI
    public Image fadeBlack; //fades in and out
    public Text winOrLose;
    public GameObject lootRecieved;
    public Text totalLoot;
    public Image[] lootIcon;
    public Text[] lootText;
    public Text replayDemo;

    private void Awake()
    {
        Debug.Log("bci start");
        fadeBlack.gameObject.SetActive(true);
        //player = GameObject.Find("Player");
        ph = player.GetComponent<PlayerHealth>();
        enemy = GameObject.FindGameObjectWithTag("BattleEnemy");
        StartCoroutine(StartStuff());
        canSpawn = true;
        burgerPosition = originalBurgerPosition;
        finalCombo = new int[componentCap];
        turns = 1;
        StartCoroutine(ComponentSpawn(KeyCode.Space, 3, bottomBun, 0)); //bottom bun must spawn before others
        ingredientINV[0] = 1;
        ingredientINV[10] = 1;
        //IconDimmer();
        IconTextUpdate();
        StartCoroutine(enableCheats());
        //StartCoroutine(FadeImageToZeroAlpha(1, fadeBlack));
        StartCoroutine(setComboText(""));
    }

    //called on start
    void Start () {
        gameObject.SetActive(false);
    }

    void IconTextUpdate()
    {
        for (int i = 0; i < 9; i++)
        {
            if (iconText[i] != null)
            {
                iconText[i].text = ingredientINV[i + 1].ToString();
            }
        }
    }

    void IconDimmer() //dims icons that are at 0 inventory
    {
        for (int i = 0; i < 9; i++)
        {
            if (ingredientINV[i] == 0 && i != 0)
            {
                iconAnim[i].SetBool("Faded", true);
            }
        }
    }

    public IEnumerator enableCheats () //press p for unlimited ammo
    {
        yield return new WaitUntil(() => Input.GetKeyDown(KeyCode.P) == true);
        ph.playerHealth = 100;
        for (int i = 1; i < 10; i++)
        {
            if (ingredientINV[i] == 0)
            {
                iconAnim[i-1].SetBool("Faded", false);
            }
            ingredientINV[i] = 99;
        }
        IconTextUpdate();
        StartCoroutine(enableCheats());
    }

    public IEnumerator ComponentSpawn(KeyCode key, float pixels, Image prefab, int identity)//controls how components spawn 
    //key: corresponding keyboard key 
    //pixels: number of pixels to occupy 
    //prefab: desired prefab 
    //identity: 0 = buns, 1 = tomato, 2 = lettuce, 3 = onion, 4 = bacon, 5 = sauce, 6 = pickles, 7 = ketchup, 8 = mustard, 9 = cheese, 10 = patty
    {
        yield return new WaitForSeconds(0.01f);
        yield return new WaitUntil(() => Input.GetKeyDown(key) == true || topPlaced == true);
        if (topPlaced == false)
        {
            yield return new WaitUntil(() => canSpawn == true);
            
            if (ingredientINV[identity] > 0)
            {
                if (identity >= 1 && identity <= 9)
                {
                    ingredientINV[identity] = ingredientINV[identity] - 1;
                }
                canSpawn = false;
                if(identity != 0)
                    componentNumber++;
                if (identity > 0 && identity < 10)
                {
                    //iconAnim[identity - 1].SetTrigger("Flash");
                }
                switch (identity) //checks identity of placed prefab to determine position relative to BurgerPosition, and also pass the correct arguments to the coroutine. There's probably a more efficient way to do this.
                {
                    case 0: //called only for bottom bun. starts the process
                        Debug.Log("Component0");
                        IngredientsInfo();
                        Instantiate(prefab, new Vector3(CombatUI.transform.localPosition.x, burgerPosition - 6.25f, 0), Quaternion.identity);
                        ResetAttack();
                        StartCoroutine(ComponentSpawn(KeyCode.A, 1, tomato, 1));
                        StartCoroutine(ComponentSpawn(KeyCode.S, 1, lettuce, 2));
                        StartCoroutine(ComponentSpawn(KeyCode.D, 1, onion, 3));
                        if (isTutorial == false)
                        {
                            StartCoroutine(ComponentSpawn(KeyCode.Q, 1, bacon, 4));
                            StartCoroutine(ComponentSpawn(KeyCode.W, 1, sauce, 5));
                            StartCoroutine(ComponentSpawn(KeyCode.E, 1, pickles, 6));

                            StartCoroutine(ComponentSpawn(KeyCode.Z, 1, ketchup, 7));
                            StartCoroutine(ComponentSpawn(KeyCode.X, 1, mustard, 8));
                            StartCoroutine(ComponentSpawn(KeyCode.C, 1, cheese, 9));
                        }
                        StartCoroutine(ComponentSpawn(KeyCode.LeftShift, 2, patty, 10));
                        StartCoroutine(TopBunSpawn());
                        ph.protag.SetTrigger("BunPlace");
                        ph.protag.SetBool("isBunPlaced", true);
                        break;
                    case 1:
                        Debug.Log("Component1");
                        burgerPosition = burgerPosition + 3.25f;
                        Instantiate(prefab, new Vector3(CombatUI.transform.localPosition.x, burgerPosition, 0), Quaternion.identity);
                        StartCoroutine(ComponentSpawn(KeyCode.A, 1, tomato, 1));
                        burgPlaceAnim();
                        break;
                    case 2:
                        Debug.Log("Component2");
                        burgerPosition = burgerPosition + 3.25f;
                        Instantiate(prefab, new Vector3(CombatUI.transform.localPosition.x, burgerPosition, 0), Quaternion.identity);
                        StartCoroutine(ComponentSpawn(KeyCode.S, 1, lettuce, 2));
                        burgPlaceAnim();
                        break;
                    case 3:
                        Debug.Log("Component3");
                        burgerPosition = burgerPosition + 3.25f;
                        Instantiate(prefab, new Vector3(CombatUI.transform.localPosition.x, burgerPosition, 0), Quaternion.identity);
                        StartCoroutine(ComponentSpawn(KeyCode.D, 1, onion, 3));
                        burgPlaceAnim();
                        break;
                    case 4:
                        Debug.Log("Component4");
                        burgerPosition = burgerPosition + 3.25f;
                        Instantiate(prefab, new Vector3(CombatUI.transform.localPosition.x, burgerPosition, 0), Quaternion.identity);
                        StartCoroutine(ComponentSpawn(KeyCode.Q, 1, bacon, 4));
                        burgPlaceAnim();
                        break;
                    case 5:
                        Debug.Log("Component 5");
                        Instantiate(prefab, new Vector3(CombatUI.transform.localPosition.x, burgerPosition, 0), Quaternion.identity);
                        StartCoroutine(ComponentSpawn(KeyCode.W, 1, sauce, 5));
                        burgPlaceAnim();
                        break;
                    case 6:
                        Debug.Log("Component 6");
                        burgerPosition = burgerPosition + 3.25f;
                        Instantiate(prefab, new Vector3(CombatUI.transform.localPosition.x, burgerPosition, 0), Quaternion.identity);
                        StartCoroutine(ComponentSpawn(KeyCode.E, 1, pickles, 6));
                        burgerPosition = burgerPosition - 3.25f;
                        burgPlaceAnim();
                        break;
                    case 7:
                        Debug.Log("Component 7");
                        burgerPosition = burgerPosition + 3.25f;
                        Instantiate(prefab, new Vector3(CombatUI.transform.localPosition.x, burgerPosition, 0), Quaternion.identity);
                        StartCoroutine(ComponentSpawn(KeyCode.Z, 1, ketchup, 7));
                        burgerPosition = burgerPosition - 3.25f;
                        burgPlaceAnim();
                        break;
                    case 8:
                        Debug.Log("Component 8");
                        burgerPosition = burgerPosition + 3.25f;
                        Instantiate(prefab, new Vector3(CombatUI.transform.localPosition.x, burgerPosition, 0), Quaternion.identity);
                        StartCoroutine(ComponentSpawn(KeyCode.X, 1, mustard, 8));
                        burgerPosition = burgerPosition - 3.25f;
                        burgPlaceAnim();
                        break;
                    case 9:
                        Debug.Log("Component 9");
                        Instantiate(prefab, new Vector3(CombatUI.transform.localPosition.x, burgerPosition, 0), Quaternion.identity);
                        StartCoroutine(ComponentSpawn(KeyCode.C, 1, cheese, 9));
                        burgPlaceAnim();
                        break;
                    case 10:
                        Debug.Log("Component 10");
                        burgerPosition = burgerPosition + 4.55f;
                        Instantiate(prefab, new Vector3(CombatUI.transform.localPosition.x, burgerPosition, 0), Quaternion.identity);
                        StartCoroutine(ComponentSpawn(KeyCode.LeftShift, 2, patty, 10));
                        ph.DealDamage(2);
                        burgPlaceAnim();
                        break;
                }
                
                if (identity != 0)
                {
                    addToCombo(identity);
                    IconTextUpdate();
                    if (ingredientINV[identity] == 0)
                    {
                        iconAnim[identity-1].SetTrigger("Dim");
                    }
                }
            }
        }
    }

    IEnumerator TopBunSpawn() //Triggers when the cap is reached or space is pressed a second time.
    {
        yield return new WaitUntil(() => Input.GetKeyDown(KeyCode.Space) == true || (canSpawn == true && componentNumber >= componentCap));
        canSpawn = false;
        if (componentNumber >= componentCap)
        {
            yield return new WaitForSeconds(0.5f);
        }
        yield return new WaitUntil(() => canSpawn == true);
        componentNumber = 0;
        topPlaced = true;
        Instantiate(topBun, new Vector3(CombatUI.transform.localPosition.x, burgerPosition + 6.25f - sinkBP, 0), Quaternion.identity);
        executeCombo();
        FinalInfo();
        if(!isTutorial)
            yield return new WaitUntil(() => Input.GetKeyDown(KeyCode.Space) == true && eb.movingBackwards == false || Input.GetKeyDown(KeyCode.LeftControl) == true);
        else
            yield return new WaitUntil(() => Input.GetKeyDown(KeyCode.Space) == true && te.movingBackwards == false || Input.GetKeyDown(KeyCode.LeftControl) == true);
        if (Input.GetKeyDown(KeyCode.LeftControl) == true)
        {
            StartCoroutine(ClearBurger());
        } else if (Input.GetKeyDown(KeyCode.Space) == true)
        {
            ph.protag.SetTrigger("BurgerThrow");
            ph.protag.SetBool("isBunPlaced", false);
            if (heal > 0)
            {
                ph.HealDamage(Mathf.RoundToInt(heal));
            }
            StartCoroutine(ClearBurger());
        }
    }

    public void LaunchBurger () //unsure if any of this will calculate correctly. Treat with caution. called from protag attack animation
    {
        if (eb != null)
        {
            if (crying > 0)
            {
                eb.cryingStacks = eb.cryingStacks + crying;
                //crying icon
            }
            if (slow > 0)
            {
                eb.slowStacks = eb.slowStacks + slow;
                //slow icon
            }
            critRoll = Random.Range(1, 100);
            if (critRoll <= critChance)
            {
                finalDamage = finalDamage * 2;
                StartCoroutine(eb.setAboveText("Critical Hit!"));
            }
            eb.TakeDamage(finalDamage);
            eb.drops = eb.drops + dropMult;
            if (dropMult > 0)
            {
                StartCoroutine(eb.setAboveText("+" + dropMult + " Drops!"));
            }
        }
        gameObject.SetActive(false);
    }

    IEnumerator ClearBurger() //resets most variables
    {
        spawnReset = true;
        topPlaced = false;
        pattyDropped = false;
        heal = 0;
        burgerPosition = originalBurgerPosition;
        formerBurgerPosition = originalBurgerPosition;
        if (noCombo == true)
        {
            yield return new WaitForSeconds(0.1f);
        }
        else
        {
            yield return new WaitForSeconds(2f);
            noCombo = false;
        }
        clearText();
        spawnReset = false;
        StartCoroutine(ComponentSpawn(KeyCode.Space, 3, bottomBun, 0));
        bounceTrigger = 0;
    }

    void IngredientsInfo ()
    {
        for (int i = 0; i < infoText.Length; i++)
        {
            infoText[i].enabled = true;
        }
        dropText.enabled = false;
        healText.enabled = false;
        cryingText.enabled = false;
        critChanceText.enabled = false;
        armorPenText.enabled = false;
        damageTypeText.enabled = false;
        slowText.enabled = false;
        damageText.enabled = false;
    }

    void FinalInfo ()
    {
        for (int i = 0; i < infoText.Length; i++)
        {
            infoText[i].enabled = false;
        }
        dropText.enabled = true;
        healText.enabled = true;
        cryingText.enabled = true;
        critChanceText.enabled = true;
        armorPenText.enabled = true;
        damageTypeText.enabled = true;
        slowText.enabled = true;
        damageText.enabled = true;
}

    void addToCombo(int component) // adds component number to array in order, then activates info text. Also where attack calculations occur
    {
        if (fcArray < componentCap) { 
        finalCombo[fcArray] = component;
        fcArray++;
            switch (component)
            {
                case 0:
                    break;
                case 1: //tomato
                    componentCount[component]++;
                    damage = damage + 1;
                    if (componentCount[component] == 1)
                    {
                        DropMultUpdate(3, false);
                        StartCoroutine(setComboText("+3 Loot Drops, +1 Damage"));
                    }
                    else if (componentCount[component] == 2)
                    {
                        DropMultUpdate(2, false);
                        StartCoroutine(setComboText("+2 Loot Drops, +1 Damage"));
                    }
                    else if (componentCount[component] == 3)
                    {
                        DropMultUpdate(1, false);
                        StartCoroutine(setComboText("+1 Loot Drops, +1 Damage"));
                    }
                    else
                    {
                        StartCoroutine(setComboText("+0 Loot Drops, Too Many Tomatoes"));
                    }
                    finalDamageCalculator();
                    break;
                case 2: //lettuce
                    componentCount[component]++;
                    damage = damage + 1;
                    if (componentCount[component] == 1)
                    {
                        HealUpdate(10, false);
                        StartCoroutine(setComboText("+10 Shield, +1 Damage"));
                    }
                    else if (componentCount[component] == 2)
                    {
                        HealUpdate(5, false);
                        StartCoroutine(setComboText("+5 Shield, +1 Damage"));
                    }
                    else if (componentCount[component] == 3)
                    {
                        HealUpdate(3, false);
                        StartCoroutine(setComboText("+3 Shield, +1 Damage"));
                    }
                    else
                    {
                        StartCoroutine(setComboText("+0 Shield, Too Much Lettuce"));
                    }
                    finalDamageCalculator();
                    break;
                case 3: //onion                
                    componentCount[component]++;
                    damage = damage + 1;
                    if (componentCount[component] <= 3)
                    {
                        CryingUpdate(1, false);
                        StartCoroutine(setComboText("+1 Crying, +1 Damage"));
                    }
                    else
                    {
                        StartCoroutine(setComboText("+0 Crying, Too Many Onions"));
                    }
                    finalDamageCalculator();
                    break;
                case 4: //bacon
                    componentCount[component]++;
                    damage = damage + 1;
                    if (componentCount[component] == 1)
                    {
                        DamageMultUpdate(10, false);
                        StartCoroutine(setComboText("+10% Damage, + 1 Damage"));
                    }
                    else if (componentCount[component] == 2)
                    {
                        DamageMultUpdate(5, false);
                        StartCoroutine(setComboText("+5% Damage, + 1 Damage"));
                    }
                    else if (componentCount[component] == 3)
                    {
                        DamageMultUpdate(3, false);
                        StartCoroutine(setComboText("+3% Damage, + 1 Damage"));
                    }
                    else
                    {
                        StartCoroutine(setComboText("+0% Damage, Too Much Bacon"));
                    }
                    finalDamageCalculator();
                    break;
                case 5: //sauce
                    componentCount[component]++;
                    damage = damage + 1;
                    if (componentCount[component] == 1)
                    {
                        CritUpdate(10, false);
                        StartCoroutine(setComboText("+10% Critical, + 1 Damage"));
                    }
                    else if (componentCount[component] == 2)
                    {
                        CritUpdate(5, false);
                        StartCoroutine(setComboText("+5% Critical, + 1 Damage"));
                    }
                    else if (componentCount[component] == 3)
                    {
                        CritUpdate(3, false);
                        StartCoroutine(setComboText("+3% Critical, + 1 Damage"));
                    }
                    else
                    {
                        StartCoroutine(setComboText("+0% Critical, Too Much Sauce"));
                    }
                    finalDamageCalculator();
                    break;
                case 6: //pickles
                    componentCount[component]++;
                    damage = damage + 1;
                    if (componentCount[component] == 1)
                    {
                        ArmorPenUpdate(20, false);
                        StartCoroutine(setComboText("+20% Penetration, + 1 Damage"));
                    }
                    else if (componentCount[component] == 2)
                    {
                        ArmorPenUpdate(10, false);
                        StartCoroutine(setComboText("+10% Penetration, + 1 Damage"));
                    }
                    else if (componentCount[component] == 3)
                    {
                        ArmorPenUpdate(5, false);
                        StartCoroutine(setComboText("+5% Penetration, + 1 Damage"));
                    }
                    else
                    {
                        StartCoroutine(setComboText("+0% Penetration, Too Many Pickles"));
                    }
                    finalDamageCalculator();
                    break;
                case 7: //ketchup
                    componentCount[component]++;
                    damage = damage + 1;
                    if (componentCount[component] == 1)
                    {
                        DamageTypeUpdate(true, false);
                        StartCoroutine(setComboText("Ketchup DMG, + 1 Damage"));
                    }
                    else
                    {
                        StartCoroutine(setComboText("Ketchup Already Applied"));
                    }
                    finalDamageCalculator();
                    break;
                case 8: //mustard
                    componentCount[component]++;
                    damage = damage + 1;
                    if (componentCount[component] == 1)
                    {
                        DamageTypeUpdate(false, false);
                        StartCoroutine(setComboText("Mustard DMG, + 1 Damage"));
                    }
                    else
                    {
                        StartCoroutine(setComboText("Mustard Already Applied"));
                    }
                    finalDamageCalculator();
                    break;
                case 9: //cheese
                    componentCount[component]++;
                    damage = damage + 1;
                    if (componentCount[component] <= 3)
                    {
                        StartCoroutine(setComboText("+1 Slow, +1 Damage"));
                        SlowUpdate(1, false);
                    }
                    else
                    {
                        StartCoroutine(setComboText("+0 Slow, Too Much Cheese"));
                    }
                    finalDamageCalculator();
                    break;
                case 10: //patty
                    componentCount[component]++;
                    if (pattyDropped == false)
                    {
                        pattyDropped = true;
                        damage = damage + 10;
                        StartCoroutine(setComboText("Damage Activated"));
                    }
                    else
                    {
                        if (componentCount[component] == 2)
                        {
                            damage = damage + 10;
                            StartCoroutine(setComboText("+10 Damage"));
                        }
                        else if (componentCount[component] == 3)
                        {
                            damage = damage + 5;
                            StartCoroutine(setComboText("+5 Damage"));
                        }
                        else if (componentCount[component] == 4)
                        {
                            StartCoroutine(setComboText("+0 Damage, Too Many Patties"));
                        }
                    }
                    finalDamageCalculator();
                    break;
            }
        }
    }

    //following functions are for combos
    void clearText()
    {
        /*for (int i = 0; i < componentCap; i++)
        {
            infoText[i].text = "--";
        }*/
    }

    bool CheckCombo(int[] comboCheck) // checks if final combo is a combo
    {
       if (finalCombo.Length != comboCheck.Length)
            return false;
       for (int i = 0; i < finalCombo.Length; i++)
       {
            if (finalCombo[i] != comboCheck[i])
                return false;
       }
       return true;
    }

    IEnumerator setComboText(string combo)
    {
        comboText.text = combo;
        yield return new WaitUntil(() => Input.GetKeyDown(KeyCode.Space) == true || Input.GetKeyDown(KeyCode.LeftControl) == true);
        comboText.text = "";
    }

    void executeCombo() // checks all combos against final combo, resets array for next loop in the subcombo check
    {
        fcArray = 0;
        if (CheckCombo(simpleCombo) == true) //checking combos
        {
            StartCoroutine(setComboText("Make It Fast Combo: +1 Slow, You Poor Soul"));
            SlowUpdate(1, false);
        }
        else if (CheckCombo(classicCombo) == true) //checking combos
        {
            StartCoroutine(setComboText("The Classic Combo: +10% Crit Chance"));
            CritUpdate(10, false);
        }
        else if (CheckCombo(veggieCombo) == true) //checking combos
        {
            StartCoroutine(setComboText("The Vegetarian(?) Combo: +5 Healing"));
            HealUpdate(5, false);
        }
        else if (CheckCombo(weepCombo) == true) //checking combos
        {
            StartCoroutine(setComboText("Make Them Weep Combo: +1 Crying, +1 Slow"));
            SlowUpdate(1, false);
            CryingUpdate(1, false);
        }
        else if (CheckCombo(doubleCombo) == true) //checking combos
        {
            StartCoroutine(setComboText("Double Combo: +20% Penetration"));
            ArmorPenUpdate(20, false);
        }
        else if (CheckCombo(classicCombo3) == true) //checking combos
        {
            StartCoroutine(setComboText("The Classic Combo 3: +5% to Everything"));
            DropMultUpdate(1, false);
            HealUpdate(2, false);
            DamageMultUpdate(5, false);
            CritUpdate(5, false);
            ArmorPenUpdate(5, false);
        }
        else if (CheckCombo(baconCombo) == true) //checking combos
        {
            StartCoroutine(setComboText("Definitely Kosher Combo: +15 Damage on First Turn"));
            if (turns == 1)
            {
                damage = damage + 15;
                finalDamageCalculator();
            }
        }
        else
        {
            noCombo = true;
        }
        CheckSubCombos(finalCombo);
    }

    //following functions are for streamlining text and mechanics updates to variables
    void finalDamageCalculator()
    {
        if (pattyDropped == true)
        {
            finalDamage = damage * (1f + (damageMult * 0.01f));
        }
        else
        {
            finalDamage = 0;
        }
        damageText.text = "Damage: " + finalDamage.ToString("F2");
    }

    void DropMultUpdate(int x, bool reset)
    {
        if (reset == false)
        {
            dropMult = dropMult + x;

        } else
        {
            dropMult = 0;
        }
        dropText.text = "+" + dropMult + " Loot Drops";
    }

    void HealUpdate(int x, bool reset)
    {
        if (reset == false)
        {
            heal = heal + x;
        }
        else
        {
            heal = 0;
        }
        healText.text = "+" + heal + " Healing";
    }

    void CryingUpdate(int x, bool reset)
    {
        if (reset == false)
        {
            crying = crying + x;
            if (crying != 1)
            {
                cryingText.text = "+" + crying + " Crying Stacks";
            }
            else
            {
                cryingText.text = "+" + crying + " Crying Stack";
            }
        } else
        {
            crying = 0;
            cryingText.text = "+" + crying + " Crying Stacks";
        }
    }

    void DamageMultUpdate(int x, bool reset)
    {
        if (reset == false)
        {
            damageMult = damageMult + x;
        } else
        {
            damageMult = 0;
        }
    }

    void CritUpdate(int x, bool reset)
    {
        if (reset == false)
        {
            critChance = critChance + x;
        } else
        {
            critChance = 0;
        }
        critChanceText.text = critChance + "% Critical Chance";
    }

    void ArmorPenUpdate(int x, bool reset)
    {
        if (reset == false)
        {
            if (armorPen < 100)
            {
                armorPen = armorPen + x;
            }
        }
        else
        {
            armorPen = 0;
        }
        armorPenText.text = "+" + armorPen + "% Penetration";
    }

    void DamageTypeUpdate(bool isKetchup, bool reset)
    {
        if (isKetchup == true && reset == false)
        {
            if (mustardDamage == true)
            {
                mustardDamage = false;
                damageTypeText.text = "Bun Damage";
            }
            else
            {
                ketchupDamage = true;
                damageTypeText.text = "Ketchup Damage";
            }
        } else if (reset == false && isKetchup == false)
        {
            if (ketchupDamage == true)
            {
                ketchupDamage = false;
                damageTypeText.text = "Bun Damage";
            }
            else
            {
                mustardDamage = true;
                damageTypeText.text = "Mustard Damage";
            }
        } else if (reset == true)
        {
            ketchupDamage = false;
            mustardDamage = false;
            damageTypeText.text = "Bun Damage";
        }
    }

    void SlowUpdate(int x, bool reset)
    {
        if (reset == false)
        {
            slow = slow + 1;
            if (slow != 1)
            {
                slowText.text = "+" + slow + " Slowing Stacks";
            }
            else
            {
                slowText.text = "+" + slow + " Slowing Stack";
            }
        }
        else
        {
            slow = 0;
            slowText.text = "+" + slow + " Slowing Stacks";
        }
    }
    
    void ResetAttack() //Resets variables controlled by all above functions
    {
        damage = 0;
        finalDamageCalculator();
        DropMultUpdate(0, true);
        HealUpdate(0, true);
        CryingUpdate(0, true);
        DamageMultUpdate(0, true);
        CritUpdate(0, true);
        ArmorPenUpdate(0, true);
        DamageTypeUpdate(false, true);
        SlowUpdate(0, true);
    }

    public void UponDeath () //triggers through animation on death
    {
        playerDead = true;
        ClearBurger();
        ResetAttack();
        StartCoroutine(FadeImageToFullAlpha(2, fadeBlack));
    }

    public IEnumerator whenBlackScreen () //controls UI, triggering when screen is fully black
    {
        //yield return new WaitUntil(() => fadeBlack.color.a == 1);
        yield return new WaitForSeconds(1f);
        Debug.Log("fully black");
        if (playerDead == false)
        {
            Debug.Log("player alive");
            winOrLose.enabled = true;
            winOrLose.text = "Order Filled";
            yield return new WaitForSeconds(0.5f);
            float totalDrops = 0;
            if (eb != null)
            {
                 totalDrops = eb.drops;
            }
            else {
                 totalDrops = te.drops;
            }
            lootRecieved.SetActive(true);
            totalLoot.text = totalDrops.ToString() + " Ingredients Recieved";
            yield return new WaitForSeconds(0.25f);
            for (int j = 0; j < lootIcon.Length; j++) //uses enemy behavior and expended ingredients to figure out drops. Or it will, eventually.
            {
                lootIcon[j].enabled = true;
                lootText[j].text = "+1";
            }
            yield return new WaitForSeconds(0.5f);
            replayDemo.enabled = true;
        }
        else if (playerDead == true)
        {
            winOrLose.enabled = true;
            winOrLose.text = "Employee Terminated";
            yield return new WaitForSeconds(0.5f);
            replayDemo.enabled = true;
        }
    }

    public IEnumerator FadeImageToFullAlpha(float t, Image i) //used to fade in and fade out scene, and controls UI for death
    {
        i.color = new Color(i.color.r, i.color.g, i.color.b, 0);
        bool coCalled = false;
        while (i.color.a < 1.0f)
        {
            i.color = new Color(i.color.r, i.color.g, i.color.b, i.color.a + (Time.deltaTime / t));
            yield return null;
        }
        while (i.color.a == 1.0f && coCalled == false)
        {
            StartCoroutine(whenBlackScreen());
            coCalled = true;
            yield return null;
        }
    }

    public IEnumerator FadeImageToZeroAlpha(float t, Image i)
    {
        i.color = new Color(i.color.r, i.color.g, i.color.b, 1);
        while (i.color.a > 0.0f)
        {
            i.color = new Color(i.color.r, i.color.g, i.color.b, i.color.a - (Time.deltaTime / t));
            yield return null;
        }
    }

    public void CheckSubCombos(int[] givenCombo) {
        bool found = false;
        int numCombo = 0;
        if (givenCombo.Length > componentCap)
            broken = true;
        for (int i = 0 ; i < givenCombo.Length && !found; i++) {
            if (!broken)
            {
                for (int j = 0; j < givenCombo.Length - twoPatt.Length - 1; j++)
                {
                    if (givenCombo[i + j] != twoPatt[j])
                    {
                        break;
                    }
                    else if (j == twoPatt.Length - 1)
                    {
                        numCombo++;
                    }
                }
            }
        }
        if (numCombo > 0) {         // take off some of the damage multiplier
            damage = damage/1.5f;
            finalDamageCalculator();
            if (noCombo)
            {
                StartCoroutine(setComboText("Two Patties In A Row: -Damage"));
            }

        }
        found = false;

        // insert more subcombo checks here
        for (int i = 0; i < componentCap; i++) //returns finalcombo array to all 0
        {
            finalCombo[i] = 0;
        }
        for (int i = 0; i < componentCount.Length; i++) {
            componentCount[i] = 0;
        }
    }

    public void burgPlaceAnim() {
        
        if (ph.protag.GetBool("OddIngredient"))
        {
            ph.protag.SetBool("OddIngredient", false);
        }
        else {
            ph.protag.SetBool("OddIngredient", true);
        }
        ph.protag.SetTrigger("IngredientPlace");
    }

    public IEnumerator StartStuff() {
        while (enemy == null) {
            yield return new WaitForEndOfFrame();
            enemy = GameObject.FindGameObjectWithTag("BattleEnemy");
        }
        //yield return new WaitUntil(() => enemy != null);
        eb = enemy.GetComponent<EnemyBehavior>();
        if (eb == null) {
            te = enemy.GetComponent<TutorialEnemy>();
        }
        if (te != null) {
            isTutorial = true;
        }
    }
}